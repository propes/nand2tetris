namespace VMTranslator.Lib
{
    public enum CommandType
    {
        Arithmetic,
        StackOperation
    }
}