namespace VMTranslator.Lib
{
    public interface IPointerPushCommandTranslator : IStackOperationCommandTranslator
    {
    }
}