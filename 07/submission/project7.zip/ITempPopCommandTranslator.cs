namespace VMTranslator.Lib
{
    public interface ITempPopCommandTranslator : IStackOperationCommandTranslator
    {
    }
}