namespace VMTranslator.Lib
{
    public interface IConstantPushCommandTranslator : IStackOperationCommandTranslator
    {
    }
}