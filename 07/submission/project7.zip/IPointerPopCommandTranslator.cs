namespace VMTranslator.Lib
{
    public interface IPointerPopCommandTranslator : IStackOperationCommandTranslator
    {
    }
}