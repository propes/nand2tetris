namespace VMTranslator.Lib
{
    public interface IFileReader
    {
        string[] ReadFileToArray(string filename);
    }
}