namespace VMTranslator.Lib
{
    public interface IMemorySegmentPopCommandTranslator : IStackOperationCommandTranslator
    {
    }
}