namespace VMTranslator.Lib
{
    public interface ITempPushCommandTranslator : IStackOperationCommandTranslator
    {
    }
}