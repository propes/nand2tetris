namespace VMTranslator.Lib
{
    public interface IStaticPopCommandTranslator : IStackOperationCommandTranslator
    {
    }
}