namespace VMTranslator.Lib
{
    public interface IStaticPushCommandTranslator : IStackOperationCommandTranslator
    {
    }
}