namespace VMTranslator.Lib
{
    public interface IMemorySegmentPushCommandTranslator : IStackOperationCommandTranslator
    {
    }
}